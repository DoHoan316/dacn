# UniAssist AI — Frontend TV4

Frontend React/Vite cho giao diện trợ lý AI tra cứu thông tin sinh viên.

## Yêu cầu
- Node.js tương thích với phiên bản Vite trong `package.json`
- npm

## Cài đặt và chạy
```bash
npm install
npm run dev
```
Mở địa chỉ Local do Vite hiển thị trong terminal.

## Cấu hình môi trường
Tạo file `.env` ở cùng cấp với `package.json`. Có thể sao chép `.env.example` rồi chỉnh:

```env
VITE_API_BASE_URL=http://127.0.0.1:8000
VITE_DEMO_MODE=true
```

- `VITE_API_BASE_URL`: địa chỉ gốc của Backend, không thêm `/api/chat`.
- `VITE_DEMO_MODE=true`: bật phản hồi demo có nhãn rõ ràng để kiểm tra UI khi chưa có Backend.
- `VITE_DEMO_MODE=false`: gọi `POST {VITE_API_BASE_URL}/api/chat`. Cần khớp endpoint và cấu trúc API do nhóm Backend cung cấp.

Sau khi sửa `.env`, khởi động lại Vite để biến môi trường được nạp lại.

## API tạm thời đang được giả định
Request:
```json
{
  "message": "Câu hỏi của sinh viên",
  "session_id": "conversation-id"
}
```

Frontend hiện thử đọc câu trả lời từ một trong các trường `answer`, `response`, `reply`, `message`, `result.answer`, `data.answer`, `data.response`. Nguồn thử đọc từ `citations`, `sources`, `references`, `documents` hoặc các trường lồng tương ứng.

Đây chỉ là lớp tương thích dự phòng, **không thay thế tài liệu API chính thức**. Khi nhận được Backend thật, cần xác nhận lại request, response, CORS và quy tắc trích dẫn. Không tuyên bố tích hợp thành công trước khi kiểm thử thực tế.

## Chức năng Frontend
- Tách các thành phần chat, tin nhắn, ô nhập, loading và danh sách nguồn.
- Chặn câu hỏi rỗng; Enter gửi, Shift+Enter xuống dòng; giới hạn 2.000 ký tự.
- Loading và thông báo lỗi kết nối/HTTP/định dạng API.
- Tạo, đổi và xóa hội thoại trong lịch sử trình duyệt.
- Lưu lịch sử bằng `localStorage` trên trình duyệt hiện tại.
- Chỉ hiển thị nguồn và liên kết khi API cung cấp thông tin tương ứng.
- Responsive cho màn hình nhỏ.

## Kiểm tra trước khi bàn giao
```bash
npm run build
npm run lint
```

### Checklist thủ công
1. Mở màn hình ban đầu, kiểm tra câu hỏi gợi ý.
2. Gửi câu rỗng: không được gửi.
3. Gửi câu hỏi: loading hiển thị, nút gửi bị khóa trong lúc chờ.
4. Chuyển sang hội thoại khác rồi quay lại: tin nhắn được giữ.
5. Tải lại trang: lịch sử trên cùng trình duyệt được khôi phục.
6. Xóa hội thoại: chỉ xóa lịch sử phía trình duyệt, không tuyên bố xóa dữ liệu máy chủ.
7. Với `VITE_DEMO_MODE=true`, xác nhận câu trả lời ghi rõ là demo.
8. Với demo tắt và Backend không chạy, giao diện phải hiện lỗi kết nối, không tự tạo câu trả lời giả.
9. Khi Backend thật có nguồn, kiểm tra tên tài liệu/trang/URL hiển thị đúng dữ liệu API.
10. Kiểm tra ở chiều rộng desktop và mobile.

## Những việc cần xác nhận khi ghép nhóm
- Endpoint chính thức, phương thức HTTP, request/response JSON.
- CORS cho địa chỉ Frontend.
- Tên trường citations và schema từng nguồn.
- Quy ước session/conversation ID.
- URL tài liệu có thể mở được từ trình duyệt hay không.
